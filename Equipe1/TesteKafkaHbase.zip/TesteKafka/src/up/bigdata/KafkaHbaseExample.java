package up.bigdata; 

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import com.google.protobuf.ServiceException;

import java.io.IOException;
import java.util.Collections;
import java.util.Properties;

// REF: http://www.baeldung.com/hbase
public class KafkaHbaseExample {
	
	private final static String TOPIC = "test3";
    private final static String BOOTSTRAP_SERVERS = "localhost:9092";
    
    private final static String TABELA = "tabela";
    private final static String FAMILIA_COLUNA = "fc1";
    
    private final static String ANO = "ano";
    private final static String MES = "mes";
    private final static String NOME = "nome";
    private final static String SALARIO = "salario";
    private final static String JETONS = "jetons";    
    
    private static Consumer<Long, String> createConsumer() {
        
    	final Properties props = new Properties();
        
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "KafkaExampleConsumer");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

        // Create the consumer using props
        final Consumer<Long, String> consumer = new KafkaConsumer<>(props);
        
        // Subscribe to the topic
        consumer.subscribe(Collections.singletonList(TOPIC));
        
        return consumer;
    }
    
    void runConsumer() throws InterruptedException {
        final Consumer<Long, String> consumer = createConsumer();
        final int giveUp = 100000000;   
        int noRecordsCount = 0;
        
        System.out.printf("Iniciando Consumer...");
        
        while (true) {
            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(100);
            if (consumerRecords.count() == 0) {            	
                noRecordsCount++;
                if (noRecordsCount > giveUp) 
                	break;
                else continue;
            }            
            
            for (ConsumerRecord<Long, String> record : consumerRecords) {
            	System.out.println("Registro: " + record.key() + " " + record.value() + " " + record.partition() + " " + record.offset());
			            
            	try {
            		//Aqui deveria fazer o parsing do registro que veio do kafka
            		//O Exemplo abaixo passa os dados fixos a titulo de exemplo
            		put("2019", "12", "41414242322", "Juca2", "123", "50");
            	} catch (Exception e) {
            		e.printStackTrace();
            	}
            }
           
            consumer.commitAsync();
        }
        consumer.close();
        System.out.println("DONE");
    }  
    
    private void put(String ano, String mes, String cpf, String nome, String salario, String jetons) throws Exception {
    	
    	System.out.println("Iniciando PUT... ");
     	TableName table1 = TableName.valueOf(TABELA);

        Table table = getConnection().getTable(table1);   	        
		
		byte[] row1 = Bytes.toBytes(ano + "_" + mes + "_" + cpf + "_" + nome);
		Put p = new Put(row1);
		p.addImmutable(FAMILIA_COLUNA.getBytes(), ANO.getBytes(), Bytes.toBytes(ano)); 
		p.addImmutable(FAMILIA_COLUNA.getBytes(), MES.getBytes(), Bytes.toBytes(mes));
		p.addImmutable(FAMILIA_COLUNA.getBytes(), NOME.getBytes(), Bytes.toBytes(nome));
		p.addImmutable(FAMILIA_COLUNA.getBytes(), SALARIO.getBytes(), Bytes.toBytes(salario));
		p.addImmutable(FAMILIA_COLUNA.getBytes(), JETONS.getBytes(), Bytes.toBytes(jetons));
		table.put(p); 
		System.out.println("Finalizando PUT... ");
    }
    
    public Connection getConnection() throws Exception {
    	Configuration config = HBaseConfiguration.create(); 

    	config.addResource(new Path("/home/cloudera/Desktop/hbase-site.xml"));
        
        HBaseAdmin.checkHBaseAvailable(config);            
        return ConnectionFactory.createConnection(config);        	 
    }    

    public static void main(String... args) throws Exception {
    	KafkaHbaseExample teste = new KafkaHbaseExample();
    	teste.runConsumer();
    }

}
