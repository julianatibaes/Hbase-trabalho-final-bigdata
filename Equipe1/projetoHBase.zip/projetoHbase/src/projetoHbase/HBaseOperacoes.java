package projetoHbase;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;


// FONTE: https://github.com/eugenp/tutorials/tree/master/hbase
public class HBaseOperacoes {

    /**
     * Drop tables if this value is set true.
     */
    static boolean INITIALIZE_AT_FIRST = true;

    private final TableName tabela = TableName.valueOf("ano_mes_cpf_nome");
    private final String fc = "fc";
    private final String colAno = "ano";
    private final String colMes = "mes";
    private final String colNome = "nome";
    private final String colSal = "salario";
    private final String colJetons = "jetons";
    
    private void createTable(Admin admin) throws IOException {
        HTableDescriptor desc = new HTableDescriptor(tabela);
        desc.addFamily(new HColumnDescriptor(fc));
        admin.createTable(desc);
    }

    private void put(Admin admin, Table table, 
    		String row,
    		String ano, 
    		String mes,
    		String nome,
    		String salario,
    		String jetons) throws IOException {
        System.out.println("\n*** PUT example ~inserting \"cell-data\" into Family1:Qualifier1 of Table1 ~ ***");

        // Row1 => Family1:Qualifier1, Family1:Qualifier2
        Put p = new Put(Bytes.toBytes(row));
        p.addImmutable(fc.getBytes(), (fc+":"+colAno).getBytes(), ano.getBytes());
        p.addImmutable(fc.getBytes(), (fc+":"+colMes).getBytes(), mes.getBytes());
        p.addImmutable(fc.getBytes(), (fc+":"+colNome).getBytes(), nome.getBytes());
        p.addImmutable(fc.getBytes(), (fc+":"+colSal).getBytes(), salario.getBytes());
        p.addImmutable(fc.getBytes(), (fc+":"+colJetons).getBytes(), jetons.getBytes());  
        table.put(p);

        admin.disableTable(tabela);
        try {
            HColumnDescriptor desc = new HColumnDescriptor(row);
            admin.addColumn(tabela, desc);
            System.out.println("Success.");
        } catch (Exception e) {
            System.out.println("Failed.");
            System.out.println(e.getMessage());
        } finally {
            admin.enableTable(tabela);
        }
        System.out.println("Done. ");
    }

    public void run(Configuration config,
    		String row,
    		String ano, 
    		String mes,
    		String nome,
    		String salario,
    		String jetons) throws IOException {
        try (Connection connection = ConnectionFactory.createConnection(config)) {

            Admin admin = connection.getAdmin();
        /*   
            if (!admin.tableExists(tabela)) {
                createTable(admin);
            }
*/
            Table table = connection.getTable(tabela);
            put(admin, table, row, ano, mes, nome, salario, jetons);
            
        }
    }

   
}
