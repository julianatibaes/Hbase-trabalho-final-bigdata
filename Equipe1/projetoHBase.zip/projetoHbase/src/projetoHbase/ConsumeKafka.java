package projetoHbase;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import com.google.protobuf.ServiceException;

import java.io.IOException;
import java.util.Collections;
import java.util.Properties;

//FONTE: http://cloudurable.com/blog/kafka-tutorial-kafka-consumer/index.html
public class ConsumeKafka {

	private final static String TOPIC = "servidores";
    private final static String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private HBaseOperacoes hbase;
    
	public static void main(String[] args) throws Exception,IOException, ServiceException {
		runConsumer();
		new ConsumeKafka().connect2();

	}
	
	 private static Consumer<Long, String> createConsumer() {
	      final Properties props = new Properties();
	      props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
	                                  BOOTSTRAP_SERVERS);
	      props.put(ConsumerConfig.GROUP_ID_CONFIG,
	                                  "ConsomeKafka");
	      props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
	              LongDeserializer.class.getName());
	      props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
	              StringDeserializer.class.getName());

	      // Create the consumer using props.
	      final Consumer<Long, String> consumer = new KafkaConsumer<>(props);

	      // Subscribe to the topic.
	      consumer.subscribe(Collections.singletonList(TOPIC));
	      return consumer;
	  }
	
	 static void runConsumer() throws InterruptedException {
	        final Consumer<Long, String> consumer = createConsumer();

	        final int giveUp = 100;   int noRecordsCount = 0;

	        while (true) {
	            final ConsumerRecords<Long, String> consumerRecords =
	                    consumer.poll(1000);

	            if (consumerRecords.count()==0) {
	                noRecordsCount++;
	                if (noRecordsCount > giveUp) break;
	                else continue;
	            }

	            for(ConsumerRecord<Long, String> record:consumerRecords){
	            	converteDados(record);
	            	 
	            	// jogar os dados convertidos para a tabela
	            	
	            }
	            

	            consumer.commitAsync();
	        }
	        consumer.close();
	        System.out.println("Lendo os CSV inseridos no Kafka");
	    }

	 void connect2() throws IOException, ServiceException {

	        Configuration config = HBaseConfiguration.create();

	       //String path = this.getClass().getClassLoader().getResource("hbase-site.xml").getPath();
	       
	        String path = "/home/cloudera/Desktop/hbase-site.xml";
	  
	        config.addResource(new Path(path));

	        try {
	            HBaseAdmin.checkHBaseAvailable(config);
	        } catch (MasterNotRunningException e) {
	            System.out.println("HBase is not running." + e.getMessage());
	            return;
	        }

	        HBaseOperacoes hbase = new HBaseOperacoes();
	        // pegar os dados convertidos e enviar o objeto.
	        hbase.run(config, "2", "2010", "2", "juliana", "1212", "234");
	       
	        
	    }
	 
	 private static void converteDados(ConsumerRecord<Long, String> record){
		 System.out.printf("Consumer Record:(%d, %s, %d, %d)\n",
                 record.key(), 
                 record.value(),
                 record.partition(), record.offset());
	 }
	 // falta enviar o objeto populado com os dados que vieram da linha 
}
