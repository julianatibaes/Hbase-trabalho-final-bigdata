package projetoHbase;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

import com.google.protobuf.ServiceException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;

import java.io.IOException;


// FONTE: http://www.baeldung.com/hbase
// Fonte Kafka: https://kafka.apache.org/quickstart

public class EnviaDados {

	 private final static String TOPIC = "servidores";
	    private final static String BOOTSTRAP_SERVERS = "localhost:9092";

	    
	public static void main(String[] args) throws Exception,IOException, ServiceException {
		
		if (args.length == 0) {
	        runProducer(5);
	    } else {
	        runProducer(Integer.parseInt(args[0]));
	    }

		new EnviaDados().connect();
	}
	
	private static Producer<Long, String> createProducer() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                                            BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "KafkaExampleProducer");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                                        LongSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                                    StringSerializer.class.getName());
        return new KafkaProducer<>(props);
    }
	
	static void runProducer(final int sendMessageCount) throws Exception {
	      final Producer<Long, String> producer = createProducer();
	      long time = System.currentTimeMillis();

	      try {
	          for (long index = time; index < time + sendMessageCount; index++) {
	              final ProducerRecord<Long, String> record =
	                      new ProducerRecord<>(TOPIC, index,
	                                  "Hello Mom " + index);

	              RecordMetadata metadata = producer.send(record).get();

	              long elapsedTime = System.currentTimeMillis() - time;
	              System.out.printf("sent record(key=%s value=%s) " +
	                              "meta(partition=%d, offset=%d) time=%d\n",
	                      record.key(), record.value(), metadata.partition(),
	                      metadata.offset(), elapsedTime);

	          }
	      } finally {
	          producer.flush();
	          producer.close();
	      }
	}
	
	 private void connect() throws IOException, ServiceException {
	        Configuration config = HBaseConfiguration.create();

	       //String path = this.getClass().getClassLoader().getResource("hbase-site.xml").getPath();
	       
	        String path = "/home/cloudera/Desktop/hbase-site.xml";
	        		
	        config.addResource(new Path(path));

	        try {
	            HBaseAdmin.checkHBaseAvailable(config);
	        } catch (MasterNotRunningException e) {
	            System.out.println("HBase is not running." + e.getMessage());
	            return;
	        }

	        HBaseOperacoes hbase = new HBaseOperacoes();
	        hbase.run(config, "1", "2010", "2", "juliana", "1212", "234");
	    }
}
