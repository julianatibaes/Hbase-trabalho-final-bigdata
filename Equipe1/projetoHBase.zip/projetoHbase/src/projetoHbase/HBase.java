package projetoHbase;

public class HBase {
	
    private  String fc;
    private  String colAno;
    private  String colMes;
    private  String colNome;
    private  String colSal ;
    private  String colJetons;
    
    
	public HBase(String fc, String colAno, String colMes, String colNome,
			String colSal, String colJetons) {
		super();
		this.fc = fc;
		this.colAno = colAno;
		this.colMes = colMes;
		this.colNome = colNome;
		this.colSal = colSal;
		this.colJetons = colJetons;
	}
	
	public String getFc() {
		return fc;
	}
	public String getColAno() {
		return colAno;
	}
	public String getColMes() {
		return colMes;
	}
	public String getColNome() {
		return colNome;
	}
	public String getColSal() {
		return colSal;
	}
	public String getColJetons() {
		return colJetons;
	}
    
    
    
}
